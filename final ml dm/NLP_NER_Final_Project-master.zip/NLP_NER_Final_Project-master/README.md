# NLP_NER_Final_Project
### Student Name: Nguyen Xuan Tung
### Student ID: M22.ICT.006